
This website helped me understand the GroupBy function: 
https://realpython.com/pandas-groupby/ 
---------------------------------------------
This one to understand how to use GroupBy with order by
https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.nlargest.html
---------------------------------------------
This decumentation helped me with the pandas read_csv parematers 
https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html